package com.starwars.domains;

import lombok.*;

import javax.persistence.*;

@Data
@Entity
@Table(name = "planet")
public class Planet {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String name;

    private String climate;

    private String terrain;

    @Column(name = "amount_appearances")
    private Long amountAppearances;
}
