package com.starwars.gateways.rest;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.starwars.gateways.SwApiGateway;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;

@Component
@Slf4j
public class SwApi implements SwApiGateway {

    private static final String HEADER_NAME = "user-agent";
    private static final String HEADER_VALUE = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36";

    @Value("${uri.swapi}")
    private String uri;

    @Autowired
    private RestTemplate restTemplate;

    @Override
    public Long getAmountAppearances(String namePlanet) {
        log.info("Trying to get Planet from http://swapi.co/");

        Long amount = null;

        try {
            ResponseEntity<String> response = restTemplate.exchange(uri + namePlanet, HttpMethod.GET, getHttpEntity(), String.class);
            amount = deserialize(response.getBody());

        } catch (Exception ex) {
            log.error(ex.getMessage());
        }

        return amount;
    }

    private HttpEntity<String> getHttpEntity() {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.add(HEADER_NAME, HEADER_VALUE);
        HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

        return entity;
    }

    public Long deserialize(String json) {
        Gson gson = new Gson();
        JsonObject jsonClass = gson.fromJson(json, JsonObject.class);

        Integer amount = jsonClass.get("results")
                            .getAsJsonArray()
                            .get(0)
                            .getAsJsonObject()
                            .get("films")
                            .getAsJsonArray()
                            .size();

        return amount.longValue();
    }
}
