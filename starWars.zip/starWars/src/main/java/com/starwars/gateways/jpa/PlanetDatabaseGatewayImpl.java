package com.starwars.gateways.jpa;

import com.starwars.domains.Planet;
import com.starwars.gateways.PlanetDatabaseGateway;
import com.starwars.gateways.SwApiGateway;
import com.starwars.gateways.jpa.repository.PlanetRepository;
import com.starwars.http.json.PlanetRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class PlanetDatabaseGatewayImpl implements PlanetDatabaseGateway {

    @Autowired
    private PlanetRepository planetRepository;

    @Autowired
    private SwApiGateway swApiGateway;

    @Override
    public List<Planet> listAll() {
        return planetRepository.findAll();
    }

    @Override
    public Planet findByName(String name) {
        return planetRepository.findByName(name);
    }

    @Override
    public Planet findById(Long id) {
        return planetRepository.findById(id).isPresent() ? planetRepository.findById(id).get() : null;
    }

    @Override
    public void deleteById(Long id) {
        planetRepository.deleteById(id);
    }

    @Override
    public Planet insert(PlanetRequest request) {
        Planet planet = new Planet();

        planet.setName(request.getName());
        planet.setClimate(request.getClimate());
        planet.setTerrain(request.getTerrain());
        planet.setAmountAppearances(swApiGateway.getAmountAppearances(request.getName()));

        return planetRepository.save(planet);
    }
}
