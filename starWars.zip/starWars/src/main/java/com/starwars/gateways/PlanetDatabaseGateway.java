package com.starwars.gateways;

import com.starwars.domains.Planet;
import com.starwars.http.json.PlanetRequest;

import java.util.List;

public interface PlanetDatabaseGateway {

    List<Planet> listAll();

    Planet findByName(String name);

    Planet findById(Long id);

    void deleteById(Long id);

    Planet insert(PlanetRequest request);
}
