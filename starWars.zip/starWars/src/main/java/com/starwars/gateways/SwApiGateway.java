package com.starwars.gateways;

public interface SwApiGateway {

    Long getAmountAppearances(String namePlanet);
}
