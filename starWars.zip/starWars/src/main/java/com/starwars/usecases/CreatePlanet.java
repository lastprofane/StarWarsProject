package com.starwars.usecases;

import com.starwars.domains.Planet;
import com.starwars.gateways.PlanetDatabaseGateway;
import com.starwars.http.json.PlanetRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CreatePlanet {

    @Autowired
    private PlanetDatabaseGateway planetDatabaseGateway;

    public Planet insert(PlanetRequest request) {
        log.info("Try to insert planets");

        try {
            return planetDatabaseGateway.insert(request);
        } catch (Exception ex) {
            log.error(ex.getMessage());

            throw new RuntimeException("Error to retrieve data from postgres.");
        }
    }
}
