package com.starwars.usecases;

import com.starwars.domains.Planet;
import com.starwars.gateways.PlanetDatabaseGateway;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.List;

@Service
@Slf4j
public class FindPlanet {

    @Autowired
    private PlanetDatabaseGateway planetDatabaseGateway;

    public List<Planet> listAll() {
        log.info("Try to find all planets");

        try {
            return planetDatabaseGateway.listAll();
        } catch (Exception ex) {
            log.error(ex.getMessage());

            throw new RuntimeException("Error to retrieve data from postgres.");
        }
    }

    public Planet byName(String name) {
        log.info("Try to find planet by name");

        try {
            return planetDatabaseGateway.findByName(name);
        } catch (Exception ex) {
            log.error(ex.getMessage());

            throw new RuntimeException("Error to retrieve data from postgres.");
        }
    }

    public Planet byId(Long id) {
        log.info("Try to find planet by ID");

        try {
            return planetDatabaseGateway.findById(id);
        } catch (Exception ex) {
            log.error(ex.getMessage());

            throw new RuntimeException("Error to retrieve data from postgres.");
        }
    }

    public void deleteById(Long id) {
        log.info("Delete planet by ID");

        try {
            planetDatabaseGateway.deleteById(id);
        } catch (Exception ex) {
            throw new RuntimeException("Error to retrieve data from postgres.");
        }
    }
}
