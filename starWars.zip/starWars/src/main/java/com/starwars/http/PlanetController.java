package com.starwars.http;

import com.starwars.http.json.PlanetRequest;
import com.starwars.http.json.PlanetResponse;
import com.starwars.http.json.mapper.PlanetResponseMappers.PlanetResponseMapper;
import com.starwars.usecases.CreatePlanet;
import com.starwars.usecases.FindPlanet;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.OK;

@RestController
@RequestMapping("/api/planet")
@Slf4j
public class PlanetController {

    private static final String APPLICATION_JSON_VALUE = "application/json";

    @Autowired
    private FindPlanet findPlanet;

    @Autowired
    private CreatePlanet createPlanet;

    @ApiOperation(value = "Resource to Insert Planets", response = PlanetResponse.class)
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Created"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @ResponseStatus(CREATED)
    @PostMapping(value = "/insert")
    public ResponseEntity<PlanetResponse> insert(
            @ApiParam(name = "planetRequest", value = "Planet object that will be created", required = true) @RequestBody @Valid final PlanetRequest planetRequest) {
        log.info("Insert Planet '{}'", planetRequest.getName());

        return new ResponseEntity(PlanetResponseMapper.MAPPER.planetResponse(createPlanet.insert(planetRequest)), OK);
    }

    @ApiOperation(value = "Resource to list Planets", response = PlanetResponse.class, responseContainer = "List")
    @ApiResponses(value = {
            @ApiResponse(code = 20, message = "Ok"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @ResponseStatus(OK)
    @GetMapping(value = "/listAll", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<List<PlanetResponse>> listAll() {
        log.info("Listing all Planets");

        return new ResponseEntity(PlanetResponseMapper.MAPPER.listPlanetResponse(findPlanet.listAll()), OK);
    }

    @ApiOperation(value = "Resource to find Planets by name", response = PlanetResponse.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Ok"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @ResponseStatus(OK)
    @GetMapping(value = "/findByName", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<PlanetResponse> findByName(
            @ApiParam(name = "name", value = "Name of Planet", required = true) @RequestParam("name") final String name) {
        log.info("Listing Planet by name='{}'", name);

        return new ResponseEntity(PlanetResponseMapper.MAPPER.planetResponse(findPlanet.byName(name)), OK);
    }

    @ApiOperation(value = "Resource to find Planets by ID", response = PlanetResponse.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Ok"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @ResponseStatus(OK)
    @GetMapping(value = "/findById", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<PlanetResponse> findById(
            @ApiParam(name = "identification", value = "Identification of Planet", required = true) @RequestParam("identification") final Long identification) {
        log.info("Listing Planet by ID=''{}", identification);

        return new ResponseEntity(PlanetResponseMapper.MAPPER.planetResponse(findPlanet.byId(identification)), OK);
    }

    @ApiOperation(value = "Resource to Remove Planets by ID", response = HttpStatus.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Ok"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @ResponseStatus(OK)
    @DeleteMapping(value = "/deleteById", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> deleteById(
            @ApiParam(name = "identification", value = "Identification of Planet", required = true) @RequestParam("identification") final Long identification) {
        log.info("Delete Planet by ID='{}'", identification);

        findPlanet.deleteById(identification);

        return new ResponseEntity(OK);
    }
}
