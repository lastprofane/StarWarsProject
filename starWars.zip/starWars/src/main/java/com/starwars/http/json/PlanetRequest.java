package com.starwars.http.json;

import lombok.Data;

import java.io.Serializable;

@Data
public class PlanetRequest implements Serializable {

    private String name;

    private String climate;

    private String terrain;
}
