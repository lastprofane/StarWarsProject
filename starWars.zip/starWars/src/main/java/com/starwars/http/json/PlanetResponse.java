package com.starwars.http.json;

import lombok.Data;

import java.io.Serializable;

@Data
public class PlanetResponse implements Serializable {

    private Long id;

    private String name;

    private String climate;

    private String terrain;

    private Long amountAppearances;
}
