package com.starwars.http.json.mapper;

import com.starwars.domains.Planet;
import com.starwars.http.json.PlanetResponse;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

import static org.mapstruct.ReportingPolicy.IGNORE;

@Mapper(unmappedTargetPolicy = IGNORE)
public interface PlanetResponseMappers {

    List<PlanetResponse> listPlanetResponse(List<Planet> planets);

    PlanetResponse planetResponse(Planet planets);

    enum PlanetResponseMapper {
        ;
        public static final PlanetResponseMappers MAPPER = Mappers.getMapper(PlanetResponseMappers.class);
    }
}
