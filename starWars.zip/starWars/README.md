## Description ##

POC - Micro Service to insert, remove and list of planets from Star Wars.

## Swagger

[Swagger-ui] = http://localhost:8080/swagger-ui.html

## Compile and run the app
'mvn install && mvn spring-boot:run'

## Description of the architecture

[Clean-Architecture] = https://8thlight.com/blog/uncle-bob/2012/08/13/the-clean-architecture.html

# domains package

This package contains domain entities.

# usecases package

This package contains the application business rules.

# gateways package

This package contains the implementation of the gateways defined in the
`usecases`. Frameworks and drivers, example: SpringData Repository.

# http

This package contains the rest controllers.

# json

This package contains the response json of controllers

# config

This package contains the application settings.

## Docker

# Command line
    $ docker pull postgres
    $ docker run -d -e POSTGRES_USER=user -e POSTGRES_PASSWORD=123456 --name db-my -p 5432:5432 --restart=always postgres

On Postgres
CREATE TABLE public.planet
(
  id bigint NOT NULL,
  amount_appearances bigint,
  climate character varying(255),
  name character varying(255),
  terrain character varying(255),
  CONSTRAINT planet_pkey PRIMARY KEY (id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE public.planet
  OWNER TO "user";